# send_streaming_to_slack.py
# 9) 스트리밍 출력 받기 (토큰 나오자마자 표시) → Slack 전송

import os
import sys
from sys import stdout
import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


def main():
    # 0) 환경 변수 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id = os.getenv("CHANNEL_ID")
    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    # 1) 스트리밍 출력 (콘솔)
    print("🚀 Ollama 스트리밍 시작...\n")
    stream = ollama.chat(
        model="gemma3:1b",
        messages=[{"role": "user", "content": "생성형 AI의 장단점을 항목별로 정리해줘."}],
        stream=True,
        options={"temperature": 0.3},
    )

    buf = []
    try:
        for chunk in stream:
            token = chunk["message"]["content"]
            buf.append(token)
            stdout.write(token)
            stdout.flush()
    except KeyboardInterrupt:
        print("\n⛔ 스트리밍 중단됨.")
    except Exception as e:
        sys.exit(f"[스트리밍 오류] {e}")

    full_text = "".join(buf)
    print("\n\n전체 응답:", full_text)

    # 2) Slack으로 전송
    client = WebClient(token=slack_token)
    try:
        result = client.chat_postMessage(
            channel=channel_id,
            text="*💬 Ollama 스트리밍 결과 (gemma3:1b)*\n```" + full_text.strip() + "```",
        )
        print("\n✅ Slack 전송 완료:", result["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"[Slack 전송 실패] {msg}")


if __name__ == "__main__":
    main()
