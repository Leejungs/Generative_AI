# send_translation_to_slack.py
# 6) 번역(Translation) — 스타일 전환 포함 → Slack 전송

import os
import sys
import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    """Ollama 호출 함수"""
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )
    return (resp.get("message") or {}).get("content", "").strip()


def main():
    # 0) 환경 변수 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id  = os.getenv("CHANNEL_ID")
    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    # 1) 원문 및 프롬프트
    english = """
    We propose a lightweight retrieval-augmented pipeline for customer support emails.
    The system combines semantic search with local LLM inference to provide accurate responses.
    """

    prompt = f"""
    다음 영어 문단을 '대학 강의노트' 스타일의 한국어로 번역해줘.
    필요하면 용어를 각주 형식으로 보충 설명 (각주는 괄호로).
    텍스트:
    {english}
    """

    # 2) Ollama 호출
    translation = ask("gemma3:1b", prompt, temperature=0.2)
    if not translation:
        sys.exit("Ollama 응답이 비어 있습니다.")

    # 3) Slack 전송
    client = WebClient(token=slack_token)
    try:
        result = client.chat_postMessage(
            channel=channel_id,
            text="*🌐 번역 결과 (gemma3:1b)*\n```" + translation + "```"
        )
        print("✅ Slack 전송 완료:", result["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"Slack 전송 실패: {msg}")


if __name__ == "__main__":
    main()
