# send_summarization_to_slack.py
# 5) 요약(Summarization) — 길이 제한 & 톤 제어 → Slack 전송

import os
import sys
import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    """Ollama 호출 헬퍼"""
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )
    return (resp.get("message") or {}).get("content", "").strip()


def main():
    # 0) .env 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id  = os.getenv("CHANNEL_ID")
    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    # 1) 요약할 원문 & 프롬프트
    article = """
    생성형 AI는 기업의 문서 검색, 고객지원 자동화, 코드 리뷰 등 다양한 영역에 적용되고 있다.
    특히 검색결합형(RAG) 방식은 내부 문서를 실시간으로 참조하여 최신 정보를 제공할 수 있어,
    많은 기업들이 도입을 검토하고 있다. 로컬 추론 환경에서도 충분히 활용 가능하다.
    """

    prompt = f"""
    다음 글을 3문장 이내로 요약하고, 마지막에 핵심 키워드 3개를 해시태그로 제시해줘.
    글:
    {article}
    """

    # 2) LLM 호출
    summary = ask("gemma3:1b", prompt, temperature=0.3)
    if not summary:
        sys.exit("Ollama 응답이 비어 있습니다.")

    # 3) Slack으로 전송
    client = WebClient(token=slack_token)
    try:
        result = client.chat_postMessage(
            channel=channel_id,
            text="*📝 요약 결과 (gemma3:1b)*\n```" + summary + "```"
        )
        print("✅ Slack 전송 완료:", result["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"Slack 전송 실패: {msg}")


if __name__ == "__main__":
    main()
