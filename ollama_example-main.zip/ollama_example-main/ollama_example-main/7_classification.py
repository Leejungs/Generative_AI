# send_classification_to_slack.py
# 7) 분류(Classification) — 라벨 집합 고정 & 근거 포함 → Slack 전송

import os
import sys
import json
import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


def classify_review(model, review, label_set, temperature=0):
    """리뷰 1건을 LLM으로 분류(JSON 응답)"""
    prompt = f"""
아래 리뷰를 {label_set} 중 하나로 분류하고, 한 문장 근거를 제시해.
JSON만 출력:
{{"label": <label>, "reason": <string>}}
리뷰: "{review}"
"""
    resp = ollama.chat(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        format="json",
        options={"temperature": temperature},
    )
    return json.loads((resp.get("message") or {}).get("content", "{}"))


def main():
    # 0) .env 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id  = os.getenv("CHANNEL_ID")
    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    client = WebClient(token=slack_token)

    # 1) 분류할 리뷰 목록
    reviews = [
        "배송이 빠르고 포장도 안전했어요.",
        "설명과 다른 제품이 왔고 반품 진행이 너무 느렸습니다.",
        "가격은 좋지만 내구성이 아쉽네요."
    ]
    label_set = ["positive", "neutral", "negative"]

    results = []
    for r in reviews:
        try:
            data = classify_review("gemma3:1b", r, label_set)
            results.append({
                "review": r,
                "label": data.get("label", "N/A"),
                "reason": data.get("reason", "N/A")
            })
        except Exception as e:
            results.append({
                "review": r,
                "label": "error",
                "reason": str(e)
            })

    # 2) Slack 전송용 포매팅
    summary_lines = ["*🧩 리뷰 감성 분류 결과 (gemma3:1b)*"]
    for res in results:
        summary_lines.append(
            f"\n> 리뷰: _{res['review']}_\n→ 라벨: *{res['label']}*\n→ 근거: {res['reason']}"
        )

    text = "\n".join(summary_lines)

    # 3) Slack 메시지 전송
    try:
        result = client.chat_postMessage(channel=channel_id, text=text)
        print("✅ Slack 전송 완료:", result["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"Slack 전송 실패: {msg}")


if __name__ == "__main__":
    main()
