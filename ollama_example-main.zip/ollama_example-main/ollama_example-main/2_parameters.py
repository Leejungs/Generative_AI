# send_ollama_creative_to_slack.py
# 2) Ollama (gemma3:1b) 파라미터 실험 → 결과를 Slack으로 전송

import os
import sys
import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

def main():
    # .env 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id = os.getenv("CHANNEL_ID")

    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    # 1) Ollama 옵션 설정
    options = {
        "temperature": 0.2,   # 창의성/일관성
        "num_ctx": 4096,      # 컨텍스트 윈도 (메모리/VRAM 영향)
        "num_predict": 256    # 생성 토큰 제한
    }

    # 2) Ollama 모델 호출
    resp = ollama.chat(
        model='gemma3:1b',
        messages=[{"role": "user", "content": "한 문단짜리 한국어 격언을 창의적으로 지어줘."}],
        options=options
    )

    content = (resp.get("message") or {}).get("content") or ""
    if not content.strip():
        sys.exit("Ollama 응답이 비어 있습니다.")

    # 3) Slack 메시지 전송
    client = WebClient(token=slack_token)
    try:
        result = client.chat_postMessage(
            channel=channel_id,
            text=f"*Ollama(gemma3:1b) — 파라미터 테스트 결과*\n```{content}```"
        )
        print("✅ Slack 전송 완료:", result["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"Slack 전송 실패: {msg}")

if __name__ == "__main__":
    main()
