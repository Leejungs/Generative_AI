# send_batch_summary_to_slack.py
# 10) 배치 처리 예시 — 여러 문서 요약 표 만들기 → Slack 전송

import os
import sys
import ollama
import pandas as pd
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    """Ollama 호출 헬퍼 함수"""
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )
    return (resp.get("message") or {}).get("content", "").strip()


def main():
    # 0) .env 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id = os.getenv("CHANNEL_ID")
    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    # 1) 문단 리스트
    paragraphs = [
        "전자상거래에서는 고객지원 자동화가 중요한 과제로 부상했다. AI 챗봇과 검색 시스템이 핵심이다.",
        "검색결합형(RAG) 접근은 내부 문서를 참조하여 최신 정보를 제공한다. 기업 도입이 증가하고 있다.",
        "로컬 추론은 개인정보와 기밀문서 보호에 유리하다. Ollama 같은 도구가 이를 가능하게 한다."
    ]

    # 2) 배치 요약 수행
    rows = []
    for i, p in enumerate(paragraphs, start=1):
        try:
            summary = ask("gemma3:1b", f"두 문장으로 요약하고 핵심 키워드 3개를 해시태그로: {p}", temperature=0.2)
            rows.append({"id": i, "original": p, "summary": summary})
            print(f"[{i}] ✅ 요약 완료")
        except Exception as e:
            rows.append({"id": i, "original": p, "summary": f"[오류] {e}"})
            print(f"[{i}] ❌ 오류: {e}")

    df = pd.DataFrame(rows, columns=["id", "original", "summary"])
    print("\n요약 결과:\n", df)

    # 3) Slack 메시지 구성
    slack_lines = ["*📘 배치 요약 결과 (gemma3:1b)*"]
    for _, row in df.iterrows():
        slack_lines.append(
            f"\n> *문서 {row['id']}*\n📝 원문: {row['original']}\n💡 요약: {row['summary']}"
        )

    text = "\n".join(slack_lines)

    # 4) Slack 전송
    client = WebClient(token=slack_token)
    try:
        result = client.chat_postMessage(channel=channel_id, text=text)
        print("✅ Slack 전송 완료:", result["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"[Slack 전송 실패] {msg}")


if __name__ == "__main__":
    main()
