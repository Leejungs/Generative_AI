# send_param_compare_to_slack.py
# 13) 프롬프트 엔지니어링 - 파라미터에 따른 추론 결과 비교 → Slack 전송
# 준비:
#   pip install ollama slack_sdk python-dotenv

import os
import sys
import time
from textwrap import shorten

import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


# -------------------------------
# Slack 헬퍼 (추가)
# -------------------------------
def ensure_joined(client: WebClient, channel: str):
    """
    공개 채널이면 자동 참가를 시도.
    비공개 채널은 /invite @앱이름 필요. 이미 참여 상태면 조용히 통과.
    """
    try:
        client.conversations_join(channel=channel)
    except SlackApiError as e:
        err = e.response.get("error", "")
        # 이미 참여 / 비공개 / 아카이브 등은 여기서 막힐 수 있음 → 치명 아님
        if err in ("already_in_channel", "method_not_supported_for_channel_type",
                   "channel_not_found", "is_archived", "restricted_action",
                   "not_allowed", "not_in_channel"):
            # join 불가한 경우는 그냥 알림만 하고 상위에서 처리
            pass
        else:
            raise

def send_long_text(client: WebClient, channel: str, title: str, body: str):
    """
    Slack 메시지 길이 제한 대응(분할 전송) + 자동 조인 시도 + 친절한 에러 안내
    """
    # 1) 공개 채널이면 조인 시도 (비공개는 실패 가능)
    try:
        ensure_joined(client, channel)
    except SlackApiError:
        # 무시 (아래에서 전송 시도 중 에러로 안내)
        pass

    MAX = 3500
    try:
        client.chat_postMessage(channel=channel, text=f"*{title}*")
        chunks = [body[i:i + MAX] for i in range(0, len(body), MAX)]
        for c in chunks:
            client.chat_postMessage(channel=channel, text=c)
    except SlackApiError as e:
        err = e.response.get("error", "")
        if err == "not_in_channel":
            raise RuntimeError(
                "앱/토큰 주체가 해당 채널 멤버가 아닙니다.\n"
                "- 공개 채널: CHANNEL_ID가 맞는지 확인하고, 실패 시 앱에 channels:join 권한이 있는지 확인하세요.\n"
                "- 비공개 채널: 채널에서 `/invite @앱이름` 으로 앱을 초대하세요.\n"
                "- 사용자 토큰(xoxp-)이라면 해당 사용자 계정이 채널 멤버인지 확인하세요."
            )
        elif err == "channel_not_found":
            raise RuntimeError("CHANNEL_ID가 잘못되었거나 다른 워크스페이스의 ID입니다. CHANNEL_ID를 다시 확인하세요.")
        else:
            raise RuntimeError(f"Slack 전송 실패: {e.response.data if hasattr(e,'response') else str(e)}")

def debug_channel_info(client: WebClient, channel: str):
    """
    선택: CHANNEL_ID가 올바른지, 채널 타입이 무엇인지 빠르게 점검하고 싶다면 호출.
    (공개/비공개/IM 여부 등)
    """
    try:
        info = client.conversations_info(channel=channel)
        ch = info.get("channel", {})
        return {
            "id": ch.get("id"),
            "name": ch.get("name"),
            "is_private": ch.get("is_private"),
            "is_archived": ch.get("is_archived"),
            "is_channel": ch.get("is_channel"),
        }
    except SlackApiError as e:
        return {"error": e.response.get("error", str(e))}


# -------------------------------
# 공통 유틸 (원본)
# -------------------------------
def run_chat(model: str, prompt: str, options: dict):
    """Ollama 호출 + 경과시간 측정"""
    start = time.time()
    resp = ollama.chat(model=model, messages=[{"role": "user", "content": prompt}], options=options)
    elapsed = time.time() - start
    text = (resp.get("message") or {}).get("content", "").strip()
    return text, elapsed

def compare_responses(model: str, prompt: str, configs: list, title: str, max_preview=900):
    """여러 설정으로 같은 프롬프트를 실행하고 결과 비교"""
    results = []
    for cfg in configs:
        out, sec = run_chat(model, prompt, cfg["options"])
        results.append({
            "name": cfg["name"],
            "options": cfg["options"],
            "time": sec,
            "result": out,
            "preview": shorten(out, width=max_preview, placeholder=" …")
        })
    # Slack 전송용 문자열 구성
    lines = [f"*{title}*", f"> *프롬프트:* {prompt}"]
    for r in results:
        opt_str = ", ".join(f"{k}={v}" for k, v in r["options"].items())
        lines.append(
            f"\n— *설정:* {r['name']}  _( {opt_str} )_\n"
            f"⏱️ {r['time']:.2f}s\n"
            f"```{r['preview']}```"
        )
    return "\n".join(lines), results


# -------------------------------
# 메인
# -------------------------------
def main():
    # 0) .env 로드
    load_dotenv()
    token = os.getenv("SLACK_BOT_TOKEN")
    channel = os.getenv("CHANNEL_ID")
    if not token or not channel:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")
    client = WebClient(token=token)

    # (선택) CHANNEL_ID 빠른 점검 로그
    info = debug_channel_info(client, channel)
    if "error" in info:
        print(f"[참고] conversations_info 실패: {info['error']} (비공개 채널/권한 이슈일 수 있음)")
    else:
        print(f"[채널 확인] {info}")

    model = "gemma3:1b"

    # -------------------------------
    # 1) Temperature 비교
    # -------------------------------
    temp_configs = [
        {"name": "Temperature 0.0 (최소)", "options": {"temperature": 0.0, "num_predict": 100}},
        {"name": "Temperature 0.5 (보통)", "options": {"temperature": 0.5, "num_predict": 100}},
        {"name": "Temperature 1.0 (높음)", "options": {"temperature": 1.0, "num_predict": 100}},
        {"name": "Temperature 1.5 (매우 높음)", "options": {"temperature": 1.5, "num_predict": 100}},
    ]
    body, _ = compare_responses(
        model,
        "혁신적인 스마트폰 앱 아이디어를 하나 제안해줘.",
        temp_configs,
        "🌡️ Temperature 비교 — 창의성 테스트"
    )
    send_long_text(client, channel, "🌡️ Temperature 비교", body)

    # -------------------------------
    # 2) Top-P 비교
    # -------------------------------
    top_p_configs = [
        {"name": "Top-P 0.1 (매우 집중)", "options": {"top_p": 0.1, "temperature": 0.8}},
        {"name": "Top-P 0.5 (보통)", "options": {"top_p": 0.5, "temperature": 0.8}},
        {"name": "Top-P 0.9 (기본값)", "options": {"top_p": 0.9, "temperature": 0.8}},
        {"name": "Top-P 1.0 (최대)", "options": {"top_p": 1.0, "temperature": 0.8}},
    ]
    body, _ = compare_responses(
        model,
        "AI의 미래에 대해 짧게 설명해줘.",
        top_p_configs,
        "🎯 Top-P 비교 — 토큰 선택 범위"
    )
    send_long_text(client, channel, "🎯 Top-P 비교", body)

    # -------------------------------
    # 3) Top-K 비교
    # -------------------------------
    top_k_configs = [
        {"name": "Top-K 5 (매우 제한)", "options": {"top_k": 5, "temperature": 0.8}},
        {"name": "Top-K 20 (제한적)", "options": {"top_k": 20, "temperature": 0.8}},
        {"name": "Top-K 40 (기본값)", "options": {"top_k": 40, "temperature": 0.8}},
        {"name": "Top-K 100 (넓음)", "options": {"top_k": 100, "temperature": 0.8}},
    ]
    body, _ = compare_responses(
        model,
        "클라우드 컴퓨팅의 장점 3가지를 나열해줘.",
        top_k_configs,
        "🔝 Top-K 비교 — 고려 토큰 수"
    )
    send_long_text(client, channel, "🔝 Top-K 비교", body)

    # -------------------------------
    # 4) Repeat Penalty 비교
    # -------------------------------
    repeat_configs = [
        {"name": "Repeat Penalty 1.0 (없음)", "options": {"repeat_penalty": 1.0, "temperature": 0.8}},
        {"name": "Repeat Penalty 1.1 (기본)", "options": {"repeat_penalty": 1.1, "temperature": 0.8}},
        {"name": "Repeat Penalty 1.3 (강함)", "options": {"repeat_penalty": 1.3, "temperature": 0.8}},
        {"name": "Repeat Penalty 1.5 (매우 강함)", "options": {"repeat_penalty": 1.5, "temperature": 0.8}},
    ]
    body, _ = compare_responses(
        model,
        "Python의 장점을 설명해줘. 특히 'Python'이라는 단어를 여러 번 사용해서.",
        repeat_configs,
        "🔁 Repeat Penalty 비교 — 반복 억제"
    )
    send_long_text(client, channel, "🔁 Repeat Penalty 비교", body)

    # -------------------------------
    # 5) Num Predict 비교
    # -------------------------------
    num_predict_configs = [
        {"name": "50 토큰 (짧음)", "options": {"num_predict": 50, "temperature": 0.3}},
        {"name": "100 토큰 (보통)", "options": {"num_predict": 100, "temperature": 0.3}},
        {"name": "200 토큰 (길음)", "options": {"num_predict": 200, "temperature": 0.3}},
        {"name": "500 토큰 (매우 길음)", "options": {"num_predict": 500, "temperature": 0.3}},
    ]
    body, _ = compare_responses(
        model,
        "머신러닝과 딥러닝의 차이를 자세히 설명해줘.",
        num_predict_configs,
        "📏 Num Predict 비교 — 응답 길이"
    )
    send_long_text(client, channel, "📏 Num Predict 비교", body)

    # -------------------------------
    # 6) 복합 설정 비교
    # -------------------------------
    complex_configs = [
        {
            "name": "정확한 사실 답변용",
            "options": {"temperature": 0.1, "top_p": 0.9, "top_k": 20, "repeat_penalty": 1.1, "num_predict": 200},
        },
        {
            "name": "창의적 글쓰기용",
            "options": {"temperature": 1.0, "top_p": 0.95, "top_k": 100, "repeat_penalty": 1.3, "num_predict": 300},
        },
        {
            "name": "간결한 요약용",
            "options": {"temperature": 0.3, "top_p": 0.9, "top_k": 30, "repeat_penalty": 1.2, "num_predict": 100},
        },
        {
            "name": "브레인스토밍용",
            "options": {"temperature": 1.3, "top_p": 0.95, "top_k": 80, "repeat_penalty": 1.4, "num_predict": 250},
        },
    ]
    body, _ = compare_responses(
        model,
        "전자상거래 플랫폼을 개선할 수 있는 방법을 제안해줘.",
        complex_configs,
        "⚙️ 복합 설정 비교 — 목적별 최적화"
    )
    send_long_text(client, channel, "⚙️ 복합 설정 비교", body)

    # -------------------------------
    # 7) Num CTX 비교
    # -------------------------------
    ctx_configs = [
        {"name": "2048 토큰 (작음)", "options": {"num_ctx": 2048, "temperature": 0.3}},
        {"name": "4096 토큰 (기본)", "options": {"num_ctx": 4096, "temperature": 0.3}},
        {"name": "8192 토큰 (큼)", "options": {"num_ctx": 8192, "temperature": 0.3}},
    ]
    long_text = (
        "인공지능(AI)은 컴퓨터 과학의 한 분야로, 기계가 인간의 지능적인 행동을 모방하도록 만드는 기술입니다. "
        "최근 딥러닝의 발전으로 이미지 인식, 자연어 처리, 음성 인식 등 다양한 분야에서 획기적인 성과를 내고 있습니다. "
        "특히 대규모 언어 모델(LLM)의 등장으로 챗봇, 번역, 코드 생성 등의 작업에서 인간 수준의 성능을 보이고 있습니다."
    )
    body, _ = compare_responses(
        model,
        f"다음 텍스트를 한 문장으로 요약해줘:\n\n{long_text}",
        ctx_configs,
        "💾 Num CTX 비교 — 컨텍스트 윈도우"
    )
    send_long_text(client, channel, "💾 Num CTX 비교", body)

    # -------------------------------
    # 파라미터 가이드 요약
    # -------------------------------
    guide = """
📚 *파라미터 가이드 요약*
1) Temperature: 0.0~0.3(사실), 0.5~0.7(균형), 0.8~1.2(창의), 1.3+(매우 창의)
2) Top-P: 0.1~0.5(집중), 0.9(기본), 1.0(최대)
3) Top-K: 5~20(보수), 40(기본), 80~100(다양성↑)
4) Repeat Penalty: 1.0(없음), 1.1(기본), 1.3~1.5(반복 억제↑)
5) Num Predict: 50~100(짧음), 200~300(중간), 500+(길음)
6) Num CTX: 2048(짧은 대화), 4096(기본), 8192+(긴 문서)

🎯 *추천 조합*
• 정확한 답변: temperature=0.2, top_p=0.9, top_k=30
• 창의 글쓰기: temperature=1.0, top_p=0.95, top_k=80
• 코드 생성: temperature=0.1, top_p=0.9, repeat_penalty=1.2
• 브레인스토밍: temperature=1.3, top_p=0.95, top_k=100
• 요약: temperature=0.3, num_predict=150
"""
    send_long_text(client, channel, "📚 파라미터 가이드 요약", guide.strip())

    print("✅ 모든 비교 결과를 Slack으로 전송 완료")


if __name__ == "__main__":
    main()
