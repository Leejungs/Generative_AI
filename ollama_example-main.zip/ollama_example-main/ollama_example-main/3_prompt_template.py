# send_ollama_template_to_slack.py
# 3) 프롬프트 템플릿화 (함수로 래핑) → Slack으로 결과 전송

import os
import sys
import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


# 🔹 프롬프트 템플릿 함수 정의
def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    """Ollama 모델 호출 함수"""
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )
    return (resp.get("message") or {}).get("content", "").strip()


def main():
    # 🔹 환경 변수 로드 (.env)
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id = os.getenv("CHANNEL_ID")

    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    # 🔹 LLM 호출
    task = "대한민국을 한 문장으로 설명해줘."
    answer = ask("gemma3:1b", task)

    if not answer:
        sys.exit("Ollama 응답이 비어 있습니다.")

    # 🔹 Slack으로 전송
    client = WebClient(token=slack_token)
    try:
        result = client.chat_postMessage(
            channel=channel_id,
            text=f"*Ollama(gemma3:1b) — 프롬프트 템플릿 테스트*\n> 사용자 요청: {task}\n\n```{answer}```"
        )
        print("✅ Slack 전송 완료:", result["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"Slack 전송 실패: {msg}")


if __name__ == "__main__":
    main()
