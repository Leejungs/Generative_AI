# send_mini_rag_to_slack.py
# 8) 미니 RAG — 로컬 FAISS + Ollama 결합 → Slack 전송
# 준비:
#   1) 모델 받기:  ollama pull nomic-embed-text  &&  ollama pull gemma3:1b
#   2) 설치:      pip install faiss-cpu numpy slack_sdk python-dotenv ollama

import os
import sys
import json
from typing import List, Tuple

import numpy as np
import faiss
import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


# ---------------------------
# 공통: LLM 호출
# ---------------------------
def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options) -> str:
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )
    return (resp.get("message") or {}).get("content", "").strip()


# ---------------------------
# 1) 임베딩 함수 (Ollama embeddings API)
# ---------------------------
def embed_texts(texts: List[str]) -> np.ndarray:
    vecs = []
    for t in texts:
        e = ollama.embeddings(model="nomic-embed-text", prompt=t)
        vecs.append(np.array(e["embedding"], dtype="float32"))
    return np.vstack(vecs)  # (n, d)


# ---------------------------
# 샘플 도큐먼트
# ---------------------------
DOCS = [
    "LangChain은 LLM을 외부 데이터/툴과 연결하는 프레임워크다.",
    "Ollama는 로컬에서 LLM을 쉽게 돌릴 수 있게 해주는 런타임이다.",
    "RAG는 검색 결과를 LLM 프롬프트에 주입해 최신/사내 지식을 활용한다.",
    "Gemma3 4B는 가벼운 로컬 추론에 적합한 중소형 모델이다.",
]


# ---------------------------
# 2) FAISS 색인 구축
# ---------------------------
def build_index(docs: List[str]) -> Tuple[faiss.IndexFlatIP, np.ndarray]:
    doc_vecs = embed_texts(docs)        # (N, d)
    faiss.normalize_L2(doc_vecs)        # cosine 유사도용 정규화
    index = faiss.IndexFlatIP(doc_vecs.shape[1])  # Inner Product = Cosine (정규화 후)
    index.add(doc_vecs)
    return index, doc_vecs


# ---------------------------
# 검색기
# ---------------------------
def retrieve(query: str, docs: List[str], index: faiss.IndexFlatIP, k: int = 3) -> List[Tuple[str, float]]:
    qv = embed_texts([query])           # (1, d)
    faiss.normalize_L2(qv)
    D, I = index.search(qv, k)          # D: (1,k) scores / I: (1,k) indices
    hits = []
    for score, idx in zip(D[0], I[0]):
        if idx == -1:
            continue
        hits.append((docs[idx], float(score)))
    return hits


# ---------------------------
# 3) 질의 → 검색 → 답변 생성
# ---------------------------
def rag_answer(question: str, docs: List[str], index: faiss.IndexFlatIP, k: int = 3) -> dict:
    hits = retrieve(question, docs, index, k=k)
    context = "\n".join([h[0] for h in hits])
    prompt = f"""
아래 컨텍스트를 참고해 질문에 한국어로 답해줘.
컨텍스트:
{context}

질문: {question}
답변은 간결하지만 정확하게.
"""
    answer = ask("gemma3:1b", prompt, temperature=0)
    return {
        "question": question,
        "contexts": [{"text": t, "score": s} for t, s in hits],
        "answer": answer,
    }


def main():
    # 0) 환경 변수 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id = os.getenv("CHANNEL_ID")
    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    # 1) 인덱스 빌드
    try:
        index, _ = build_index(DOCS)
    except Exception as e:
        sys.exit(f"[임베딩/색인 오류] {e}")

    # 2) 질문 → RAG 답변 생성
    question = "RAG가 왜 필요한가요?"
    try:
        result = rag_answer(question, DOCS, index, k=3)
    except Exception as e:
        sys.exit(f"[RAG 답변 생성 오류] {e}")

    # 3) Slack 전송 포맷
    lines = [
        "*🔎 미니 RAG 결과 (FAISS + Ollama)*",
        f"> *질문:* {result['question']}",
        "",
        "*Top-K 컨텍스트:*",
    ]
    for i, ctx in enumerate(result["contexts"], 1):
        lines.append(f"{i}. {ctx['text']}  (score: {ctx['score']:.3f})")
    lines.append("")
    lines.append("*답변:*")
    lines.append("```" + (result["answer"] or "").strip() + "```")

    text = "\n".join(lines)

    # 4) Slack 전송
    client = WebClient(token=slack_token)
    try:
        resp = client.chat_postMessage(channel=channel_id, text=text)
        print("✅ Slack 전송 완료:", resp["ts"])
    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"[Slack 전송 실패] {msg}")


if __name__ == "__main__":
    main()
