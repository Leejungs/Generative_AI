# send_structured_extraction_to_slack.py
# 4) 구조화 출력(JSON) 정보추출 → Slack 전송 (주문 추출 + 영화 리뷰 추출)

import os
import re
import json
import sys
from typing import Any, Dict

import ollama
from dotenv import load_dotenv
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


# ---------------------------
# 공통: Slack 전송 함수
# ---------------------------
def send_to_slack(client: WebClient, channel: str, title: str, payload: Dict[str, Any]) -> None:
    """JSON payload를 보기 좋게 포매팅해서 Slack으로 전송"""
    pretty = json.dumps(payload, indent=2, ensure_ascii=False)
    text = f"*{title}*\n```{pretty}```"
    client.chat_postMessage(channel=channel, text=text)


# ---------------------------
# 공통: LLM JSON 안전 파서
# ---------------------------
def safe_json_from_ollama(resp: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ollama의 응답에서 JSON을 안전하게 파싱.
    - format='json' 이어도 가끔 텍스트가 섞일 수 있어 대비
    - 가장 큰 JSON 블록을 찾아 파싱 시도
    """
    raw = (resp.get("message") or {}).get("content", "")
    if not raw:
        raise ValueError("빈 응답입니다.")

    # 1) 바로 JSON 시도
    try:
        return json.loads(raw)
    except Exception:
        pass

    # 2) 백업: 가장 바깥 { ... } 블록 추출
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except Exception:
            pass

    # 3) 그래도 실패하면 에러
    raise ValueError(f"JSON 파싱 실패: {raw[:200]}...")


# ---------------------------
# 주문 텍스트 예시
# ---------------------------
ORDER_TEXT = """
주문 3건:
1) 상품: 무선마우스, 수량 2, 가격 25,000원
2) 상품: 기계식 키보드, 수량 1, 가격 89,000원
3) 상품: USB-C 케이블, 수량 3, 가격 9,900원
총 배송지는 서울시 강남구 테헤란로 1
"""

ORDER_PROMPT = f"""
아래 텍스트에서 주문 항목을 JSON으로 추출해.
스키마:
{{
  "orders":[{{"item":str,"qty":int,"price_krw":int}}],
  "shipping_address": str,
  "total_price_krw": int
}}
텍스트:
{ORDER_TEXT}
반드시 JSON만 출력.
"""


# ---------------------------
# 영화 리뷰 예시
# ---------------------------
REVIEW_TEXT = """
크리스토퍼 놀란 감독의 '인터스텔라'는 SF 장르의 걸작이다. 
시각 효과가 정말 환상적이고, 한스 짐머의 음악이 영화와 완벽하게 어우러진다.
스토리도 감동적이며 과학적 고증도 뛰어나다.
다만 러닝타임이 169분으로 너무 길고, 일부 과학 설명이 일반 관객에게는 어렵게 느껴질 수 있다.
그럼에도 불구하고 꼭 봐야 할 영화다. 5점 만점에 4.5점을 주고 싶다.
"""

REVIEW_PROMPT = f"""
아래 영화 리뷰 텍스트에서 정보를 추출하여 JSON으로 출력해줘.

스키마:
{{
  "title": str,           // 영화 제목
  "director": str,        // 감독
  "genre": str,           // 장르
  "rating": float,        // 평점 (0.0 ~ 5.0)
  "pros": [str],          // 장점 리스트
  "cons": [str],          // 단점 리스트
  "recommended": bool     // 추천 여부
}}

리뷰 텍스트:
{REVIEW_TEXT}

반드시 JSON만 출력하고, 텍스트에서 유추 가능한 모든 정보를 포함해줘.
"""


def main():
    # 0) 환경 변수 (.env) 로드
    load_dotenv()
    slack_token = os.getenv("SLACK_BOT_TOKEN")
    channel_id = os.getenv("CHANNEL_ID")

    if not slack_token or not channel_id:
        sys.exit("환경변수 누락: .env에 SLACK_BOT_TOKEN, CHANNEL_ID를 설정하세요.")

    client = WebClient(token=slack_token)

    # 1) 주문 정보 JSON 추출
    try:
        order_resp = ollama.chat(
            model="gemma3:1b",
            messages=[{"role": "user", "content": ORDER_PROMPT}],
            format="json",
            options={"temperature": 0},
        )
        order_data = safe_json_from_ollama(order_resp)

        # (선택) total_price_krw 누락 시, orders 합계로 보정
        if "total_price_krw" not in order_data and "orders" in order_data:
            total = 0
            for o in order_data["orders"]:
                qty = int(o.get("qty", 0))
                price = int(o.get("price_krw", 0))
                total += qty * price
            order_data["total_price_krw"] = total

        send_to_slack(client, channel_id, "🧾 주문 정보 추출(JSON)", order_data)

    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"[Slack 오류] 주문 전송 실패: {msg}")
    except Exception as e:
        sys.exit(f"[주문 추출 오류] {e}")

    # 2) 영화 리뷰 JSON 추출
    try:
        review_resp = ollama.chat(
            model="gemma3:1b",
            messages=[{"role": "user", "content": REVIEW_PROMPT}],
            format="json",
            options={"temperature": 0},
        )
        review_data = safe_json_from_ollama(review_resp)
        send_to_slack(client, channel_id, "🎬 영화 리뷰 분석(JSON)", review_data)

    except SlackApiError as e:
        msg = getattr(e.response, "data", None) or getattr(e.response, "body", None) or str(e)
        sys.exit(f"[Slack 오류] 리뷰 전송 실패: {msg}")
    except Exception as e:
        sys.exit(f"[리뷰 추출 오류] {e}")

    print("✅ 두 결과 모두 Slack 전송 완료")


if __name__ == "__main__":
    main()
